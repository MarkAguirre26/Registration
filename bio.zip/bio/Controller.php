<?php 
include_once("class.php");

if(isset($_REQUEST['new'])) {
	postAccountDetails();
}else if (isset($_REQUEST['edit'])) {
	postAccountDetails();
}  else if (isset($_REQUEST['select'])) {
	select();
} 

function postAccountDetails() {		

	
	$Zone=  $_REQUEST['Zone'];
	$Placeofbirth=  $_REQUEST['Placeofbirth'];
	$Birthdate=  $_REQUEST['Birthdate'];
	$Gender=  $_REQUEST['Gender'];
	$Civilstatus=  $_REQUEST['Civilstatus'];
	$Citizenship=  $_REQUEST['Citizenship'];
	$Cccupation=  $_REQUEST['Occupation'];
	$Voter=  $_REQUEST['Voter'];
	$Other=  $_REQUEST['Other'];
	
	$Province=  $_REQUEST['Province'];
	$Municipality=  $_REQUEST['Municipality'];
	$Barangay=  $_REQUEST['Barangay'];
	$HouseHoldNo=  $_REQUEST['HouseHoldNo'];	
		
	


	$Lastname=  $_REQUEST['Lastname'];
	$Firstname=  $_REQUEST['Firstname'];
	$Middlename=  $_REQUEST['Middlename'];
	$Street=  $_REQUEST['Street'];	
		$Username=  $_REQUEST['Username'];
	$Password =  $_REQUEST['Password'];

$query = "";

if(isset($_REQUEST['new'])) {
	$REG_NUMBER  =  rand();
	$query = "INSERT INTO `residents`( `REG_NUMBER`, `Lastname`, `Firstname`, `Middlename`, `Street`, `Zone`, `Placeofbirth`, `Birthdate`, `Gender`, `Civilstatus`, `Citizenship`, `Cccupation`, `Voter`, `Other`, `Province`, `Municipality`, `Barangay`, `HouseHoldNo`,`Username`,`Password`) VALUES ( '$REG_NUMBER','$Lastname', '$Firstname', '$Middlename', '$Street', '$Zone', '$Placeofbirth', '$Birthdate', '$Gender', '$Civilstatus', '$Citizenship', '$Cccupation', '$Voter', '$Other', '$Province', '$Municipality', '$Barangay', '$HouseHoldNo','$Username','$Password')";
}else if (isset($_REQUEST['edit'])) {
	
	$REG_NUMBER  =  $_REQUEST['RegId'];
	$query = "UPDATE `residents` SET `REG_NUMBER`='$REG_NUMBER', `Lastname`='$Lastname', `Firstname`='$Firstname', `Middlename`='$Middlename', `Street`='$Street', `Zone`='$Zone', `Placeofbirth`='$Placeofbirth', `Birthdate`='$Birthdate', `Gender`='$Gender', `Civilstatus`='$Civilstatus', `Citizenship`='$Citizenship', `Cccupation`='$Cccupation', `Voter`='$Voter', `Other`='$Other', `Province`='$Province', `Municipality`='$Municipality', `Barangay`='$Barangay', `HouseHoldNo`='$HouseHoldNo', `Username` = '$Username', `Password` =  '$Password' WHERE (`REG_NUMBER`='$REG_NUMBER')";
} 



    $db = new MySqlClass();
    $result  =  $db->executeQuery("$query");
    echo json_encode($result);    
   
}



function select() {

	$username =  $_REQUEST['Username'];
	$password =  $_REQUEST['Password'];
	

	$db = new MySqlClass();
    $result  = $db->getData("SELECT residents.id, residents.REG_NUMBER, residents.Lastname, residents.Firstname, residents.Middlename, residents.Street, residents.Zone, residents.Placeofbirth, residents.Birthdate, YEAR (CURRENT_DATE()) - YEAR (Birthdate) AS Age, residents.Gender, residents.Civilstatus, residents.Citizenship, residents.Cccupation, residents.Voter, residents.Other, residents.Province, residents.Municipality, residents.Barangay, residents.HouseHoldNo, residents.Username,residents.Password,residents.Remark FROM residents WHERE Username = '$username' AND Password = '$password'");     
     echo json_encode($result); 
}

function validate() {	
	$username =  $_REQUEST['username'];
	$QuizID =  $_REQUEST['QuizID'];
    $db = new MySqlClass();
    $result  = $db->getData("SELECT Count(*) as total FROM scoring WHERE scoring.username = '$username' AND QuizID = '$QuizID'");   
    echo json_encode($result); 
}

?>
