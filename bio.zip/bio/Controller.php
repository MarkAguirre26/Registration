<?php 
include_once("class.php");

if(isset($_REQUEST['new'])) {
	postAccountDetails();
}else if(isset($_REQUEST['new_user'])) {
	createUserAccount();
}else if (isset($_REQUEST['edit'])) {
	postAccountDetails();
}else if (isset($_REQUEST['login'])) {
	login();
} else if (isset($_REQUEST['usersList'])) {
	usersList();
} 

function postAccountDetails() {		

	
	$Zone =  $_REQUEST['Zone'];
	$Placeofbirth=  $_REQUEST['Placeofbirth'];
	$Birthdate=  $_REQUEST['Birthdate'];
	$Gender=  $_REQUEST['Gender'];
	$Civilstatus=  $_REQUEST['Civilstatus'];
	$Citizenship=  $_REQUEST['Citizenship'];
	$Cccupation=  $_REQUEST['Occupation'];
	$Voter=  $_REQUEST['Voter'];
	$Municipality=  $_REQUEST['Municipality'];
	$Barangay=  $_REQUEST['Barangay'];
	$HouseHoldNo=  $_REQUEST['HouseHoldNo'];	
	$Lastname=  $_REQUEST['Lastname'];
	$Firstname=  $_REQUEST['Firstname'];
	$Middlename=  $_REQUEST['Middlename'];
	$Street=  $_REQUEST['Street'];	
	$senior =  $_REQUEST['senior'];	
	$four_ps = $_REQUEST['four_ps'];	
	$SK = $_REQUEST['sk'];
$address = $Street.' '.$Zone;

$query = "";
$queryAccount = "";
if(isset($_REQUEST['new'])) {
	$REG_NUMBER  =  rand();
	$query = "INSERT INTO `residents` (`lastname`, `firstname`, `middlename`, `house_no`, `address`, `zone`, `placeofbirth`, `birthdate`, `age`, `sex`, `civilstatus`, `citizenship`, `occupation`, `senior`, `voter`, `SK`, `4Ps`) VALUES ('$Lastname', '$Firstname', '$Middlename', '$HouseHoldNo', '$address', '$Zone', '$Placeofbirth', '$Birthdate', '0', '$Gender', '$Civilstatus', '$Citizenship', '$Cccupation', '$senior', '$Voter', '$SK', '$four_ps');";



}else if (isset($_REQUEST['edit'])) {
	
	$id  =  $_REQUEST['id	'];
	$query = "UPDATE `residents` SET  `Lastname`='$Lastname', `Firstname`='$Firstname', `Middlename`='$Middlename', `Street`='$Street', `Zone`='$Zone', `Placeofbirth`='$Placeofbirth', `Birthdate`='$Birthdate', `Gender`='$Gender', `Civilstatus`='$Civilstatus', `Citizenship`='$Citizenship', `Cccupation`='$Cccupation', `Voter`='$Voter', `Other`='$Other', `Province`='$Province', `Municipality`='$Municipality', `Barangay`='$Barangay', `HouseHoldNo`='$HouseHoldNo' WHERE (`id`='$id')";
} 



    $db = new MySqlClass();
    $resulta  =  $db->executeQuery($query);
    echo json_encode($resulta);   
   
}


function createUserAccount(){

		$Username =  $_REQUEST['Username'];
	    $Password =  $_REQUEST['Password'];
	    $Position =  $_REQUEST['Position'];
	    $Usertype =  $_REQUEST['Usertype'];
		$query = "INSERT INTO `accounts` (`userid`, `password`, `position`, `usertype`) VALUES ('$Username', '$Password', '$Position', '$Usertype');";
		   $db = new MySqlClass();
	    $resulta  =  $db->executeQuery($query);
	    echo json_encode($resulta);   
	}


function login() {

	$username =  $_REQUEST['Username'];
	$password =  $_REQUEST['Password'];
	$usertype =  "Official";

	$db = new MySqlClass();
    $result  = $db->getData("SELECT * FROM accounts AS a WHERE a.userid = '$username' AND a.`password` = '$password' AND a.usertype = 'Official'");     
     echo json_encode($result); 
}


function usersList(){
	$db = new MySqlClass();
    $result  = $db->getData("SELECT r.id, CONCAT( r.Lastname, ', ', r.Firstname, ' ', r.Middlename ) AS RName, r.address, CONCAT( r.Lastname, r.Firstname, r.Middlename ) AS imgURL FROM residents AS r ORDER BY r.id DESC");     
     echo json_encode($result); 
}

function validate() {	
	$username =  $_REQUEST['username'];
	$QuizID =  $_REQUEST['QuizID'];
    $db = new MySqlClass();
    $result  = $db->getData("SELECT Count(*) as total FROM scoring WHERE scoring.username = '$username' AND QuizID = '$QuizID'");   
    echo json_encode($result); 
}

?>
