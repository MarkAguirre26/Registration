<?php
$con = mysqli_connect("127.0.0.1", "root", "", "brg_104");
// if($con){
// 	echo "true";
// }else{
// 	echo "false";
// }
?>
